# Fathima Giyash — Personal Portfolio

A responsive student portfolio website built with HTML, CSS and JavaScript.

## Files
- `index.html` — website content and sections
- `style.css` — visual design and responsive layout
- `script.js` — mobile navigation and current year

## Preview on your computer
Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Create a **public** GitHub repository named `my-portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. After GitHub Pages finishes publishing, open `https://YOUR-USERNAME.github.io/my-portfolio/` (replace `YOUR-USERNAME` with your GitHub username).

## Personalise before publishing
In `index.html`, replace `YOUR-EMAIL@example.com` with your email address. Check your name, course, semester, skills and project descriptions, and edit anything that needs updating.
