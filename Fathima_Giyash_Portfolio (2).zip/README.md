# Fathima Giyash — Portfolio

A responsive personal portfolio website for Fathima Giyash.

## Files
- `index.html` — portfolio content
- `style.css` — layout, colours and responsive design
- `script.js` — mobile navigation menu

## Preview
Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Extract this ZIP file.
2. Open your GitHub repository: `FATHIMAGIYASH/my-portfolio`.
3. Choose **Add file → Upload files** and upload the four files from this folder.
4. Commit the changes to the `main` branch.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch `main` and folder `/(root)`, then click **Save**.

Your site should appear at:
`https://fathimagiyash.github.io/my-portfolio/`

If you want to add a professional email later, edit the contact section in `index.html`. Avoid publishing your personal phone number or home address.
